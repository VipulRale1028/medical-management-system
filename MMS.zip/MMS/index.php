<!-- For more projects: Visit codeastro.com  -->
<?php
error_reporting(1);
session_start();
include("dbcon.php");
if(isset($_SESSION['user_session'])){
  
  $invoice_number="CA-".invoice_number();
	header("location:home.php?invoice_number=$invoice_number");
}

   if(isset($_POST['submit'])){  //******Login Form*******
  $username =$_POST['username'];

  $password = $_POST['password'];

  $password = sha1($password);

  $select_sql = "SELECT * FROM users ";

  $select_query = mysqli_query($con,$select_sql);
   
  if($select_query){

  	while ($row =mysqli_fetch_array($select_query)) {
  		$s_username = $row['user_name'];
  		$s_password = $row['password'];
  	}
  }

 if($s_username == $username && $s_password == $password){
          
         $_SESSION['user_session'] = $s_username;
         $invoice_number="CA-".invoice_number();
 	       header("location:home.php?invoice_number=$invoice_number");


 }else{
 	  	    $error_msg = "<center><font color='red'>Login Failed</font></center>";
 }

}                  //******Login Form*******

  function invoice_number(){   //********Outputting Random Number For Invoice Number********

    $chars = "09302909209300923";

    srand((double)microtime()*1000000);

    $i = 1;

    $pass = '';

    while($i <=7){

      $num  = rand()%10;
      $tmp  = substr($chars, $num,1);
      $pass = $pass.$tmp;
      $i++;
    }
    return $pass;
                        //********Outputting Random Number For Invoice Number********
  }                       
?>

<!DOCTYPE html>
<html>
<!DOCTYPE html>
<html>
<head>
<!-- For more projects: Visit codeastro.com  -->
	<title>Medical Management System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <style>
/* Apply background image with a light blur effect */
/* General Styles */
/* General Styles */
/* General Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html, body {
    background: #e9f7f2; /* Light greenish background */
    font-family: 'Arial', sans-serif;
    height: 100%;
    width: 100%;
    overflow: hidden; /* Removes scrollbar */
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Container - Perfectly Centered */
.container {
    background: #ffffff;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    width: 90%;
    max-width: 400px;
    text-align: center;
}

/* Heading */
h1 {
    color: #106d51;
    font-size: 22px;
    margin-bottom: 20px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

/* Form Styles */
form {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
}

/* Label Styles */
label {
    font-weight: bold;
    font-size: 14px;
    color: #106d51;
    display: flex;
    align-items: center;
    margin-bottom: 8px;
}

label i {
    margin-right: 6px;
    color: #106d51;
}

/* Input Fields */
input[type="text"], 
input[type="password"] {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border: 1px solid #a4d4b4;
    border-radius: 8px;
    font-size: 15px;
    transition: border 0.3s ease-in-out;
}

input[type="text"]:focus, 
input[type="password"]:focus {
    border: 1px solid #0c774a;
    outline: none;
}

/* Submit Button */
.btn-success {
    background: #0c774a;
    color: white;
    border: none;
    padding: 14px;
    width: 100%;
    font-size: 15px;
    border-radius: 8px;
    text-transform: uppercase;
    transition: background 0.3s ease;
    cursor: pointer;
}

.btn-success:hover {
    background: #085d3b;
}

/* Error Message */
.error {
    margin-top: 10px;
    color: red;
    font-size: 14px;
}

/* Hospital Icon */
.fa-hospital {
    font-size: 50px;
    color: green;
}

/* Responsive Adjustments */
@media (max-width: 600px) {
    .container {
        width: 95%;
        padding: 30px;
    }
}



    </style>
    
</head>
<body>
   
<div class="center-container">
        <div class="content">
        <center>
    <i class="fa fa-hospital" style="font-size: 50px; color: green;"></i>
    <h1 style="color: green; font-weight: bold; font-family: 'Arial', sans-serif; 
               animation: fadeIn 1.5s ease-in-out;">
        MEDICAL MANAGEMENT SYSTEM
    </h1>
</center>
            <form method="POST">
                <table>
                    <tr>
                    <td><label for="username" style="color: black; font-weight: bold;">
    <i class="fa fa-user"></i> Username 
</label></td>
                        <td><input type="text" name="username" placeholder="" required></td>
                    </tr>
                    <tr>
                    <td><label for="password" style="color: black; font-weight: bold;">
    <i class="fa fa-lock"></i> Password 
</label></td>
                        <td><input type="password" name="password" placeholder="" required></td>
                    </tr>
                </table>

                <input type="submit" name="submit" class="btn btn-success" value="Login">
                <?php echo $error_msg; ?>
            </form>
        </div>
    </div>
 
</body>
</html>
<!-- For more projects: Visit codeastro.com  -->