<!-- For more projects: Visit codeastro.com  -->
<?php

session_start();

if(!isset($_SESSION['user_session'])){

    header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/tcal.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/tcal.js"></script>
    <script type="text/javascript">

      function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=700, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('</head><body onLoad="self.print()" style="width: 700px; font-size:11px; font-family:arial; font-weight:normal;">');          
   docprint.document.write(content_vlue); 
   docprint.document.close(); 
   docprint.focus(); 
}

      
    </script>
    <style>
      /* General Styles */
/* General Styles */
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
    margin: 0;
    padding: 0;
    color: #333;
}

.container {
    width: 90%;
    margin: 20px auto;
    background: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

h1, h2, h3, h4, h5, h6 {
    color: #2c3e50;
}

/* Table Styles */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    background: #ffffff;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

th, td {
    padding: 12px;
    text-align: left;
}

th {
    background: linear-gradient(135deg, #6a11cb, #2575fc);
    color: #ffffff;
    font-weight: bold;
}

tr:nth-child(even) {
    background-color: #f8f9fa;
}

tr:hover {
    background-color: #e9ecef;
}

/* Button Styles */
.btn {
    display: inline-block;
    padding: 10px 20px;
    font-size: 14px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    border-radius: 5px;
    margin: 5px;
    cursor: pointer;
    transition: background 0.3s ease, transform 0.2s ease;
}

.btn-default {
    background: linear-gradient(135deg, #f8f9fa, #e2e6ea);
    border: 1px solid #ccc;
    color: #333;
}

.btn-default:hover {
    background: linear-gradient(135deg, #e2e6ea, #d4d8dc);
    transform: translateY(-2px);
}

.btn-success {
    background: linear-gradient(135deg, #28a745, #218838);
    border: 1px solid #28a745;
    color: #fff;
}

.btn-success:hover {
    background: linear-gradient(135deg, #218838, #1e7e34);
    transform: translateY(-2px);
}

.btn-danger {
    background: linear-gradient(135deg, #dc3545, #c82333);
    border: 1px solid #dc3545;
    color: #fff;
}

.btn-danger:hover {
    background: linear-gradient(135deg, #c82333, #b21f2d);
    transform: translateY(-2px);
}

.btn-md {
    padding: 8px 16px;
    font-size: 12px;
}

.btn-large {
    padding: 12px 24px;
    font-size: 16px;
}

/* Form Styles */
form {
    margin-top: 20px;
}

input[type="submit"] {
    background: linear-gradient(135deg, #28a745, #218838);
    border: 1px solid #28a745;
    color: #fff;
    padding: 12px 24px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: background 0.3s ease, transform 0.2s ease;
}

input[type="submit"]:hover {
    background: linear-gradient(135deg, #218838, #1e7e34);
    transform: translateY(-2px);
}

/* Header Styles */
.center-header {
    text-align: center;
    margin-bottom: 20px;
}

.center-header h3 {
    font-size: 28px;
    color: #2575fc;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
}

/* Print Styles */
@media print {
    body {
        font-size: 11px;
        font-family: Arial, sans-serif;
    }

    .container {
        width: 100%;
        margin: 0;
        padding: 0;
        box-shadow: none;
    }

    .btn, .no-print {
        display: none;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid #000;
        padding: 5px;
    }
}
    </style>
</head>
<body>

  <div class="container">

  	<a href="home.php?invoice_number=<?php echo $_GET['invoice_number']?>"><button class="btn btn-default"><i class="icon-arrow-left"></i> Back to Sales</button></a>

    <div id="content">

	<center><div style="font:bold 25px 'Arial';">Medical Managemt System</div><br>
                       
	</center><br><br>

	<?php 
  
  $invoice_number = $_GET['invoice_number'];
  $date           = $_POST['date'];
  $paid_amount   = $_POST['paid_amount'];
	?>

  <form method="POST" action="save_invoice.php">
  	<table class="table table-bordered table-hover" border="1" cellpadding="4" cellspacing="0" style="font-family: arial; font-size: 12px;text-align:left;" width="100%">
      <tr>
       <strong><h3>Invoice Number:<?php echo $invoice_number?></h3></strong> 
        <?php echo $date?>
      </tr>
		<thead>
			<tr>
				<th> Medicine </th>
				<th> Category</th>
				<th> Quantity </th>
				<th> Price </th>
				<th> Amount </th>
			</tr>
		</thead>
    <tbody><!-- For more projects: Visit codeastro.com  -->
      <?php

         include("dbcon.php");

         $select_sql = "SELECT * FROM on_hold where invoice_number = '$invoice_number'";

         $select_query =mysqli_query($con,$select_sql);

          while($row =mysqli_fetch_array($select_query)):
      ?>
        <tr class="record">
        <td><h4><?php echo $row['medicine_name'];?></h4>
          <input type="hidden" name="medicine_name[]" value="<?php echo $row['medicine_name']?>"></td>
          <input type="hidden" name="ex_date" value="<?php echo $row['expire_date']?>">
          <input type="hidden" name="ex_date" value="<?php echo $row['category']?>">
        <td><h5><?php echo $row['category']; ?></h5></td>
        <td><h5><?php echo $row['qty']." (".$row['type'].")"; ?></h5>
          <input type="hidden" name="qty[]" value="<?php echo $row['qty']."(".$row['type'].")"; ?>">
        </td>
        <td>
        <?php
        echo "<h5>".$row['cost']."<h5>";
        ?>
        </td>
        <td>
        <?php
         echo "<h5>".$row['amount']."<h5>";
        ?>
        </td>
        </tr>
      <?php endwhile;?>
      <!-- For more projects: Visit codeastro.com  -->
        <tr>
          <td colspan="4" style=" text-align:right;"><strong style="font-size: 12px;">Total: &nbsp;</strong></td>
          <td colspan="2"><strong style="font-size: 12px;">
          <?php

          $select_sql = "SELECT sum(amount) from on_hold where invoice_number = '$invoice_number'";

          $select_sql = mysqli_query($con,$select_sql);

          while($row = mysqli_fetch_array($select_sql)){

            $amount =  $row['sum(amount)'];

            echo '<h5>'.$amount.'</h5>';

          }
          
          ?>
          </strong></td>
        </tr>

         <tr>
          <td colspan="4" style=" text-align:right;"><strong style="font-size: 12px;">Paid Amount: &nbsp;</strong></td>
          <td colspan="2"><strong style="font-size: 12px;">
          <?php

          echo '<h3>'.'₹'.$paid_amount.'</h3>';


          ?>
          </strong></td>
        </tr>
       
         <tr>
          <td colspan="4" style=" text-align:right;"><strong style="font-size: 18px;">&nbsp;&nbsp;Change Amount: &nbsp;</strong></td>
          <td colspan="2"><strong style="font-size: 12px;">
          <?php

          echo '<h3>'.'₹'.($paid_amount - $amount).'</h3>';
          
          ?>
          </strong></td>
        </tr>
      
    </tbody>
  </table><br/>
  </div>

  <input type="hidden" name="paid_amount" value="<?php echo $paid_amount?>">
  <input type="hidden" name="invoice_number" value="<?php echo $invoice_number?>">
  <input type="hidden" name="date" value="<?php echo $date?>">
  <input type="submit" name="submit" class="btn btn-success btn-large" value="Submit and Make new Sales" >
  <a href="javascript:Clickheretoprint()" class="btn btn-danger btn-md" style="float: right;"><i class="icon icon-print"></i> Print</a>

  </form>
  </body>
  </html><!-- For more projects: Visit codeastro.com  -->